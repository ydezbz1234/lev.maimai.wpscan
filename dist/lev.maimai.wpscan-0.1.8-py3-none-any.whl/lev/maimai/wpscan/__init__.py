from levrt import annot
from . import wpscan

__lev__ = annot.meta([wpscan])

